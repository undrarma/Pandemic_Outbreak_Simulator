from pymongo import MongoClient, WriteConcern, ReadPreference
from pymongo.read_concern import ReadConcern

from secrets import MONGO_CLUSTER

import json

def getStatistics(client, simulation_id):
    db = client.simulator
    statistics_docs = db.statistics

    answer = {}

    statistics_list = statistics_docs.find({"_id" : simulation_id}).next()["simulation"]
    
    answer['infectious'] = [item["groups"]["infectious"] if "infectious" in item["groups"] else 0 for item in statistics_list]
    answer['treated'] = [item["groups"]["treated"] if "treated" in item["groups"] else 0 for item in statistics_list]
    answer['susceptible'] = [item["groups"]["susceptible"] if "susceptible" in item["groups"] else 0 for item in statistics_list]
    answer['infected'] = [item["groups"]["infected"] if "infected" in item["groups"] else 0 for item in statistics_list]
    answer['cured'] = [item["groups"]["cured"] if "cured" in item["groups"] else 0 for item in statistics_list]

    return answer

def respond(err, res=None):
    return {
        'statusCode': '400' if err else '200',
        'body': json.dumps(str(err) if err else res),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
    }
    

def lambda_handler(event, context):
    operation = event['httpMethod']
    parameters = json.loads(event['body'])

    if operation == 'POST':
        client = MongoClient(MONGO_CLUSTER)
        return respond(None, getStatistics(client, parameters['simname']))
    else:
        return respond(ValueError('Unsupported method %s'%operation))