import random
import utils

from pymongo import MongoClient
from secrets import MONGO_CLUSTER

# Parameters
numDays = 100

def addInteraction(client, simulation_id, pid1, pid2, timestamp):
    db = client.simulator
    popullation = db['population_{}'.format(simulation_id)]
    myquery = {"person_id": pid1}
    newvalues = {"$push": {"interactions": {"person_id": pid2, "timestamp": timestamp}}}
    popullation.update_one(myquery, newvalues)
    myquery = {"person_id": pid2}
    newvalues = {"$push": {"interactions": {"person_id": pid1, "timestamp": timestamp}}}
    popullation.update_one(myquery, newvalues)

def main():
    client = MongoClient(MONGO_CLUSTER)
    print("Initialization started")

    # for i in range(numDays):
    #     interactionsGen()

if __name__ == "__main__":
    main()
