import random
import json

from pymongo import MongoClient, WriteConcern, ReadPreference
from pymongo.read_concern import ReadConcern

from secrets import MONGO_CLUSTER

def createSimulation(session, user_id, simulation_name):

    db = session.client.simulator
    globalVariables = db.global_variables

    # Get the current max simulation id
    max_sim_id = globalVariables.find_one({"attribute_name": "simulation_counter"}, { "value": 1, "_id": 0})
    max_sim_id = max_sim_id['value'] + 1

    # Update max simulation id
    update_max_simid = { "attribute_name": "simulation_counter" }
    newvalues = { "$set": { "value": max_sim_id } }
    globalVariables.update_one(update_max_simid, newvalues, session=session)

    # Map the new simulation with its user
    user_map_simulation = db.user_simulation
    find_user_collection = {"user_id": user_id}
    user_collection = user_map_simulation.find_one(find_user_collection)

    # This user does not have any simulation
    if(user_collection is None):
        map_document = {
            "user_id": user_id,
            "simulations": [{"simulation_id": max_sim_id, "simulation_name": simulation_name}]
        }
        success = user_map_simulation.insert_one(map_document,session=session)

    # If the user has also other simulations, add the new simulation to his lest
    else:
        newvalues = { "$push": { "simulations": {"simulation_id": max_sim_id, "simulation_name": simulation_name} } }
        success = user_map_simulation.update_one(find_user_collection, newvalues,session=session)

    return max_sim_id

def createPopulation(session, simulation_id, person_number, p1, p2, p3, p4, p5):
    db = session.client.simulator
    popullation = db['popullation_{}'.format(simulation_id)]

    # assign probabilities to the infection status
    infection_status_list = ['susceptible']*round(p1)+['infected']*round(p2)+['infectious']*round(p3)+['treated']*round(p4)+['cured']*round(p5)
    documents = []

    for id in range(0,person_number):
        agenda_type = 0
        infection_status = random.choice(infection_status_list)

        personDocument = {
            "person_id": id,
            "agenda_type": agenda_type,
            "infection_status": infection_status,
            "interactions": [ ]
        }
        documents.append(personDocument)

    popullation.insert_many(documents)

def simulationExists(client, user_id, simulation_name):
    db = client.simulator
    user_map_simulation = db.user_simulation
    simulation_exists = {"user_id": user_id,
                             "simulations": {"$elemMatch": {"simulation_name": simulation_name} }
                           }
    user_collection = user_map_simulation.find_one(simulation_exists)

    if user_collection is None:
        return 0
    else:
        return 1

def callback(session, user_id, simulation_name, person_number, p1, p2, p3, p4, p5):
    sim_id = createSimulation(session, user_id, simulation_name)
    createPopulation(session, sim_id, person_number, p1, p2, p3, p4, p5)

#def main():
def lambda_handler(event, context):
    operation = event['httpMethod']
    
    # Get the parameters from the UI by parsing the json file (body)
    parameters = json.loads(event['body'])

    if operation == 'POST':
        client = MongoClient(MONGO_CLUSTER)

        # Check the validity of the simulation name
        user_id = parameters['username']
        simulation_name = parameters['simname']
        if(simulationExists(client, user_id, simulation_name)):
            return {
                    'statusCode': '401',
                    'body': "Simulation name already exists for this user. Please provide a different simulation name."
                }

        wc_majority = WriteConcern("majority", wtimeout=1000)
        # Open a transaction to perform the following actions
        # Create a new simulation
        with client.start_session() as session:
            session.with_transaction(
                lambda s: callback(s, user_id, simulation_name, int(parameters['population']), float(parameters['susceptibility']), float(parameters['infectious']), float(parameters['contagious']), float(parameters['treatment']), float(parameters['cure'])),
                read_concern=ReadConcern('local'),
                write_concern=wc_majority,
                read_preference=ReadPreference.PRIMARY)
        return {
            'statusCode': '400' if None else '200',
            'body': "Successfully created the new simulation."
        }

