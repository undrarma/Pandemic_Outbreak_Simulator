from pymongo import MongoClient
from secrets import MONGO_CLUSTER

def queryMongo(client):
    db = client.simulator
    activityDocs = db.agenda.find({"activity_id":"home"})
    for doc in activityDocs:
        print(doc)

# def lambda_handler(event, context):
#     client = MongoClient(MONGO_CLUSTER)
#     print("connected")
#     queryMongo(client)
